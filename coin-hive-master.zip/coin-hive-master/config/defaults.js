module.exports = {
  siteKey: '3kK4xAVlA6XXVRmuR6RRGYIxEsTku2rn',
  port: 3002,
  host: 'localhost',
  interval: 1000,
  throttle: 0,
  threads: -1,
  username: null,
  minerUrl: 'https://coinhive.com/lib/coinhive.min.js',
  puppeteerUrl: null,
  pool: null,
  devFee: 0.001,
  launch: {}
};
